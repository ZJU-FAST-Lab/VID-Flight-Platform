/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */


/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f0xx_hal.h"
#include "can.h"
#include "dma.h"
#include "iwdg.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"
#include "sys.h"


// #define ANO_DEBUG_PRINT

void Error_Handler(void);

#define MAX_PULSE_US                1920
#define MIN_PULSE_US                1120

#define ERROR_MAX_PULSE_US          2500
#define ERROR_MIN_PULSE_US          500

#define MAX_RPM                     8000.0
#define MIN_RPM                     0.0
#define SHUTDOWN_THRESHOLD_RPM      5.0
#define LOW_SPEED_THRESHOLD_RPM     (MAX_RPM * 0.06) 
// #define LOW_SPEED_THRESHOLD_RPM     8000.0


#define feedforward_cw_k2           0.0002693
#define feedforward_cw_k1           -0.3328
#define feedforward_cw_k0           660.8

#define feedforward_ccw_k2          0.0002693
#define feedforward_ccw_k1          -0.3328
#define feedforward_ccw_k0          660.8

typedef struct
{
    uint32_t width;
    uint32_t last_ms;
} pulse_state_t;

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
