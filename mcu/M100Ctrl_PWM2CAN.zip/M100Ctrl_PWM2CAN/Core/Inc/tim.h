/**
  ******************************************************************************
  * File Name          : TIM.h
  * Description        : This file provides code for the configuration
  *                      of the TIM instances.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __tim_H
#define __tim_H
#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "main.h"




extern TIM_HandleTypeDef htim1;
extern TIM_HandleTypeDef htim2;
extern TIM_HandleTypeDef htim3;
extern TIM_HandleTypeDef htim14;
extern TIM_HandleTypeDef htim16;
extern TIM_HandleTypeDef htim17;


void MX_TIM1_Init(void);
void MX_TIM2_Init(void);
void MX_TIM3_Init(void);
void MX_TIM14_Init(void);
void MX_TIM16_Init(void);
void MX_TIM17_Init(void);


#define sys_us_reg   (TIM1->CNT)

typedef struct
{
    uint32_t sys_ms;
    uint32_t cycle_10ms;
} clock_t;

extern clock_t clock;

uint32_t get_sys_ms(void);
uint64_t nowtime_us(void);
float nowtime_ms(void);


#define TIMx_PWM1  TIM2
#define TIMx_PWM2  TIM16
#define TIMx_PWM3  TIM17
#define TIMx_PWM4  TIM14

#define CNT_REG_PWM1  TIMx_PWM1->CNT
#define CNT_REG_PWM2  TIMx_PWM2->CNT
#define CNT_REG_PWM3  TIMx_PWM3->CNT
#define CNT_REG_PWM4  TIMx_PWM4->CNT

#define CCR_REG_PWM1  TIMx_PWM1->CCR1
#define CCR_REG_PWM2  TIMx_PWM2->CCR1
#define CCR_REG_PWM3  TIMx_PWM3->CCR1
#define CCR_REG_PWM4  TIMx_PWM4->CCR1



#define CCER_REG_PWM1       TIMx_PWM1->CCER
#define CCER_MASK_PWM1      TIM_CCER_CC1P

#define CCER_REG_PWM2       TIMx_PWM2->CCER
#define CCER_MASK_PWM2      TIM_CCER_CC1P

#define CCER_REG_PWM3       TIMx_PWM3->CCER
#define CCER_MASK_PWM3      TIM_CCER_CC1P

#define CCER_REG_PWM4       TIMx_PWM4->CCER
#define CCER_MASK_PWM4      TIM_CCER_CC1P



typedef enum
{
    PWM_CH1 = 0,
    PWM_CH2 = 1,
    PWM_CH3 = 2,
    PWM_CH4 = 3,
    PWM_CH_NONE = -1
} pwm_ch;


typedef struct
{
    enum
    {
        WAITING_RISE = 0,
        WAITING_FALL = 1
    } state;
    uint32_t rising_ccr;
} pwm_t;

void cap_start(void);
void Pulse_CAP_Callback(pwm_ch ch, uint32_t capval);


#ifdef __cplusplus
}
#endif
#endif /*__ tim_H */

/**
  * @}
  */

/**
  * @}
  */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
