/**
  ******************************************************************************
  * File Name          : TIM.c
  * Description        : This file provides code for the configuration
  *                      of the TIM instances.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "tim.h"


TIM_HandleTypeDef htim1;
TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim14;
TIM_HandleTypeDef htim16;
TIM_HandleTypeDef htim17;
DMA_HandleTypeDef hdma_tim2_up;

clock_t clock = {0};

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
    if(htim->Instance == TIM1)
    {
        clock.sys_ms++;
        clock.cycle_10ms++;
    }
}

uint32_t get_sys_ms(void)
{
    return clock.sys_ms;
}

uint64_t nowtime_us(void)
{
    return clock.sys_ms * 1000 + sys_us_reg;
}

float nowtime_ms(void)
{
    return (float)clock.sys_ms + (float)sys_us_reg / 1000.0;
}

__weak void Pulse_CAP_Callback(pwm_ch ch, uint32_t capval)
{
    return;
}

void cap_start(void)
{
    HAL_TIM_IC_Start_IT(&htim2, TIM_CHANNEL_1);
    HAL_TIM_IC_Start_IT(&htim16, TIM_CHANNEL_1);
    HAL_TIM_IC_Start_IT(&htim17, TIM_CHANNEL_1);
    HAL_TIM_IC_Start_IT(&htim14, TIM_CHANNEL_1);
}

pwm_ch get_pwm_ch(TIM_HandleTypeDef *htim)
{
    if(htim->Instance == TIMx_PWM1)
    {
        return PWM_CH1;
    }
    else if(htim->Instance == TIMx_PWM2)
    {
        return PWM_CH2;
    }
    else if(htim->Instance == TIMx_PWM3)
    {
        return PWM_CH3;
    }
    else if(htim->Instance == TIMx_PWM4)
    {
        return PWM_CH4;
    }
    else
    {
        return PWM_CH_NONE;
    }
}

uint32_t read_ccr(pwm_ch ch)
{
    if(ch == PWM_CH1)
    {
        return CCR_REG_PWM1;
    }
    else if(ch == PWM_CH2)
    {
        return CCR_REG_PWM2;
    }
    else if(ch == PWM_CH3)
    {
        return CCR_REG_PWM3;
    }
    else if(ch == PWM_CH4)
    {
        return CCR_REG_PWM4;
    }
    else
    {
        return 0;
    }
}

void cnt_clear(pwm_ch ch)
{
    if(ch == PWM_CH1)
    {
        CNT_REG_PWM1 = 0;
    }
    else if(ch == PWM_CH2)
    {
        CNT_REG_PWM2 = 0;
    }
    else if(ch == PWM_CH3)
    {
        CNT_REG_PWM3 = 0;
    }
    else if(ch == PWM_CH4)
    {
        CNT_REG_PWM4 = 0;
    }
}

void cmd_wait_rising(pwm_ch ch)
{
    if(ch == PWM_CH1)
    {
        CCER_REG_PWM1 &= ~CCER_MASK_PWM1;
    }
    else if(ch == PWM_CH2)
    {
        CCER_REG_PWM2 &= ~CCER_MASK_PWM2;

    }
    else if(ch == PWM_CH3)
    {
        CCER_REG_PWM3 &= ~CCER_MASK_PWM3;

    }
    else if(ch == PWM_CH4)
    {
        CCER_REG_PWM4 &= ~CCER_MASK_PWM4;
    }
}

void cmd_wait_falling(pwm_ch ch)
{
    if(ch == PWM_CH1)
    {
        CCER_REG_PWM1 |= CCER_MASK_PWM1;
    }
    else if(ch == PWM_CH2)
    {
        CCER_REG_PWM2 |= CCER_MASK_PWM2;

    }
    else if(ch == PWM_CH3)
    {
        CCER_REG_PWM3 |= CCER_MASK_PWM3;
    }
    else if(ch == PWM_CH4)
    {
        CCER_REG_PWM4 |= CCER_MASK_PWM4;
    }
}

void push_ccr(pwm_ch ch, uint32_t ccr)
{
    static pwm_t pwm[4] = {0};

    if(pwm[ch].state == WAITING_RISE)
    {
        pwm[ch].rising_ccr = ccr;
        pwm[ch].state = WAITING_FALL;
        cmd_wait_falling(ch);
    }
    else if(pwm[ch].state == WAITING_FALL)
    {
        cnt_clear(ch);
        pwm[ch].state = WAITING_RISE;
        Pulse_CAP_Callback(ch, ccr - pwm[ch].rising_ccr);
        cmd_wait_rising(ch);
    }
    else
    {
        cnt_clear(ch);
        pwm[ch].state = WAITING_RISE;    
    }
}

void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim)
{
    pwm_ch ch = get_pwm_ch(htim);
    uint32_t ccr = read_ccr(ch);
    if(ch != PWM_CH_NONE)
    {
        push_ccr(ch, ccr);
    }
}

/* TIM1 init function */
void MX_TIM1_Init(void)
{
    TIM_ClockConfigTypeDef sClockSourceConfig = {0};
    TIM_MasterConfigTypeDef sMasterConfig = {0};

    htim1.Instance = TIM1;
    htim1.Init.Prescaler = 47;
    htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
    htim1.Init.Period = 999;
    htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
    htim1.Init.RepetitionCounter = 0;
    htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
    if (HAL_TIM_Base_Init(&htim1) != HAL_OK)
    {
        Error_Handler();
    }
    sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
    if (HAL_TIM_ConfigClockSource(&htim1, &sClockSourceConfig) != HAL_OK)
    {
        Error_Handler();
    }
    sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
    sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
    if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
    {
        Error_Handler();
    }
}

/* TIM2 init function */
void MX_TIM2_Init(void)
    {
    TIM_MasterConfigTypeDef sMasterConfig = {0};
    TIM_IC_InitTypeDef sConfigIC = {0};

    htim2.Instance = TIM2;
    htim2.Init.Prescaler = 47;
    htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
    htim2.Init.Period = 999999;
    htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
    htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
    if (HAL_TIM_IC_Init(&htim2) != HAL_OK)
    {
        Error_Handler();
    }
    sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
    sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
    if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
    {
        Error_Handler();
    }
    
    sConfigIC.ICPolarity = TIM_INPUTCHANNELPOLARITY_RISING;
    sConfigIC.ICSelection = TIM_ICSELECTION_DIRECTTI;
    sConfigIC.ICPrescaler = TIM_ICPSC_DIV1;
    sConfigIC.ICFilter = 0;
    if (HAL_TIM_IC_ConfigChannel(&htim2, &sConfigIC, TIM_CHANNEL_1) != HAL_OK)
    {
        Error_Handler();
    }
}

/* TIM14 init function */
void MX_TIM14_Init(void)
{
    TIM_IC_InitTypeDef sConfigIC = {0};

    htim14.Instance = TIM14;
    htim14.Init.Prescaler = 47;
    htim14.Init.CounterMode = TIM_COUNTERMODE_UP;
    htim14.Init.Period = 0xffff;
    htim14.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
    htim14.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
    if (HAL_TIM_Base_Init(&htim14) != HAL_OK)
    {
        Error_Handler();
    }
    if (HAL_TIM_IC_Init(&htim14) != HAL_OK)
    {
        Error_Handler();
    }
    sConfigIC.ICPolarity = TIM_INPUTCHANNELPOLARITY_RISING;
    sConfigIC.ICSelection = TIM_ICSELECTION_DIRECTTI;
    sConfigIC.ICPrescaler = TIM_ICPSC_DIV1;
    sConfigIC.ICFilter = 0;
    if (HAL_TIM_IC_ConfigChannel(&htim14, &sConfigIC, TIM_CHANNEL_1) != HAL_OK)
    {
        Error_Handler();
    }
}

/* TIM16 init function */
void MX_TIM16_Init(void)
{
    TIM_IC_InitTypeDef sConfigIC = {0};

    htim16.Instance = TIM16;
    htim16.Init.Prescaler = 47;
    htim16.Init.CounterMode = TIM_COUNTERMODE_UP;
    htim16.Init.Period = 0xffff;
    htim16.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
    htim16.Init.RepetitionCounter = 0;
    htim16.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
    if (HAL_TIM_Base_Init(&htim16) != HAL_OK)
    {
        Error_Handler();
    }
    if (HAL_TIM_IC_Init(&htim16) != HAL_OK)
    {
        Error_Handler();
    }
    sConfigIC.ICPolarity = TIM_INPUTCHANNELPOLARITY_RISING;
    sConfigIC.ICSelection = TIM_ICSELECTION_DIRECTTI;
    sConfigIC.ICPrescaler = TIM_ICPSC_DIV1;
    sConfigIC.ICFilter = 0;
    if (HAL_TIM_IC_ConfigChannel(&htim16, &sConfigIC, TIM_CHANNEL_1) != HAL_OK)
    {
        Error_Handler();
    }
}

/* TIM17 init function */
void MX_TIM17_Init(void)
    {
    TIM_IC_InitTypeDef sConfigIC = {0};

    htim17.Instance = TIM17;
    htim17.Init.Prescaler = 47;
    htim17.Init.CounterMode = TIM_COUNTERMODE_UP;
    htim17.Init.Period = 0xffff;
    htim17.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
    htim17.Init.RepetitionCounter = 0;
    htim17.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
    if (HAL_TIM_Base_Init(&htim17) != HAL_OK)
    {
        Error_Handler();
    }
    if (HAL_TIM_IC_Init(&htim17) != HAL_OK)
    {
        Error_Handler();
    }
    sConfigIC.ICPolarity = TIM_INPUTCHANNELPOLARITY_RISING;
    sConfigIC.ICSelection = TIM_ICSELECTION_DIRECTTI;
    sConfigIC.ICPrescaler = TIM_ICPSC_DIV1;
    sConfigIC.ICFilter = 0;
    if (HAL_TIM_IC_ConfigChannel(&htim17, &sConfigIC, TIM_CHANNEL_1) != HAL_OK)
    {
        Error_Handler();
    }
}

void HAL_TIM_Base_MspInit(TIM_HandleTypeDef* tim_baseHandle)
    {
    GPIO_InitTypeDef GPIO_InitStruct = {0};
    if(tim_baseHandle->Instance==TIM1)
    {
        /* TIM1 clock enable */
        __HAL_RCC_TIM1_CLK_ENABLE();

        /* TIM1 interrupt Init */
        HAL_NVIC_SetPriority(TIM1_BRK_UP_TRG_COM_IRQn, 0, 0);
        HAL_NVIC_EnableIRQ(TIM1_BRK_UP_TRG_COM_IRQn);
    }
    else if(tim_baseHandle->Instance==TIM14)
    {
        /* TIM14 clock enable */
        __HAL_RCC_TIM14_CLK_ENABLE();

        __HAL_RCC_GPIOB_CLK_ENABLE();
        /**TIM14 GPIO Configuration
        PB1     ------> TIM14_CH1
        */
        GPIO_InitStruct.Pin = GPIO_PIN_1;
        GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
        GPIO_InitStruct.Pull = GPIO_NOPULL;
        GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
        GPIO_InitStruct.Alternate = GPIO_AF0_TIM14;
        HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

        /* TIM14 interrupt Init */
        HAL_NVIC_SetPriority(TIM14_IRQn, 0, 0);
        HAL_NVIC_EnableIRQ(TIM14_IRQn);
    }
    else if(tim_baseHandle->Instance==TIM16)
    {
        /* TIM16 clock enable */
        __HAL_RCC_TIM16_CLK_ENABLE();

        __HAL_RCC_GPIOA_CLK_ENABLE();
        /**TIM16 GPIO Configuration
        PA6     ------> TIM16_CH1
        */
        GPIO_InitStruct.Pin = GPIO_PIN_6;
        GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
        GPIO_InitStruct.Pull = GPIO_NOPULL;
        GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
        GPIO_InitStruct.Alternate = GPIO_AF5_TIM16;
        HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

        /* TIM16 interrupt Init */
        HAL_NVIC_SetPriority(TIM16_IRQn, 0, 0);
        HAL_NVIC_EnableIRQ(TIM16_IRQn);
    }
    else if(tim_baseHandle->Instance==TIM17)
    {
        /* TIM17 clock enable */
        __HAL_RCC_TIM17_CLK_ENABLE();

        __HAL_RCC_GPIOA_CLK_ENABLE();
        /**TIM17 GPIO Configuration
        PA7     ------> TIM17_CH1
        */
        GPIO_InitStruct.Pin = GPIO_PIN_7;
        GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
        GPIO_InitStruct.Pull = GPIO_NOPULL;
        GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
        GPIO_InitStruct.Alternate = GPIO_AF5_TIM17;
        HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

        /* TIM17 interrupt Init */
        HAL_NVIC_SetPriority(TIM17_IRQn, 0, 0);
        HAL_NVIC_EnableIRQ(TIM17_IRQn);
    }
}

void HAL_TIM_IC_MspInit(TIM_HandleTypeDef* tim_icHandle)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};
    if(tim_icHandle->Instance==TIM2)
    {
        /* TIM2 clock enable */
        __HAL_RCC_TIM2_CLK_ENABLE();

        __HAL_RCC_GPIOA_CLK_ENABLE();
        /**TIM2 GPIO Configuration
        PA5     ------> TIM2_CH1
        */
        GPIO_InitStruct.Pin = GPIO_PIN_5;
        GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
        GPIO_InitStruct.Pull = GPIO_NOPULL;
        GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
        GPIO_InitStruct.Alternate = GPIO_AF2_TIM2;
        HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

        /* TIM2 interrupt Init */
        HAL_NVIC_SetPriority(TIM2_IRQn, 0, 0);
        HAL_NVIC_EnableIRQ(TIM2_IRQn);
    }
}

void HAL_TIM_Base_MspDeInit(TIM_HandleTypeDef* tim_baseHandle)
{
    if(tim_baseHandle->Instance==TIM1)
    {
        /* Peripheral clock disable */
        __HAL_RCC_TIM1_CLK_DISABLE();

        /* TIM1 interrupt Deinit */
        HAL_NVIC_DisableIRQ(TIM1_BRK_UP_TRG_COM_IRQn);
    }
    else if(tim_baseHandle->Instance==TIM14)
    {
        /* Peripheral clock disable */
        __HAL_RCC_TIM14_CLK_DISABLE();

        /**TIM14 GPIO Configuration
        PB1     ------> TIM14_CH1
        */
        HAL_GPIO_DeInit(GPIOB, GPIO_PIN_1);

        /* TIM14 interrupt Deinit */
        HAL_NVIC_DisableIRQ(TIM14_IRQn);
    }
    else if(tim_baseHandle->Instance==TIM16)
    {
        /* Peripheral clock disable */
        __HAL_RCC_TIM16_CLK_DISABLE();

        /**TIM16 GPIO Configuration
        PA6     ------> TIM16_CH1
        */
        HAL_GPIO_DeInit(GPIOA, GPIO_PIN_6);

        /* TIM16 interrupt Deinit */
        HAL_NVIC_DisableIRQ(TIM16_IRQn);
    }
    else if(tim_baseHandle->Instance==TIM17)
    {

        /* Peripheral clock disable */
        __HAL_RCC_TIM17_CLK_DISABLE();

        /**TIM17 GPIO Configuration
        PA7     ------> TIM17_CH1
        */
        HAL_GPIO_DeInit(GPIOA, GPIO_PIN_7);

        /* TIM17 interrupt Deinit */
        HAL_NVIC_DisableIRQ(TIM17_IRQn);
    }
}

void HAL_TIM_IC_MspDeInit(TIM_HandleTypeDef* tim_icHandle)
{
    if(tim_icHandle->Instance==TIM2)
    {
        /* Peripheral clock disable */
        __HAL_RCC_TIM2_CLK_DISABLE();

        /**TIM2 GPIO Configuration
        PA5     ------> TIM2_CH1
        */
        HAL_GPIO_DeInit(GPIOA, GPIO_PIN_5);

        /* TIM2 interrupt Deinit */
        HAL_NVIC_DisableIRQ(TIM2_IRQn);
    }
}

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/


