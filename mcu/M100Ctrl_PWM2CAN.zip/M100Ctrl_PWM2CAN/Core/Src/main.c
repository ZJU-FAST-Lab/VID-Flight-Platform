
#include "main.h"

#include "canmotor.h"
#include "pid.h"
#include "ANO.h"

pulse_state_t pulse[4] = {0};
float rpm[4] = {0};
PID_HANDLE hpid[4] = {0};
PID_HANDLE hpid_lowspeed[4] = {0};

void pidInit(void)
{
    hpid[0].enable = 1;
    hpid[0].enable_lim_sum_error = 1;
    hpid[0].enable_lim_output_up = 1;
    hpid[0].enable_lim_output_dn = 1;
    
    hpid[0].kp = 50;
    hpid[0].ki = 0;
    hpid[0].kd = 0;

    hpid[0].lim_sum_error = 2000;
    hpid[0].lim_output_up = MOTOR_UP_BOUND;
    hpid[0].lim_output_dn = MOTOR_DN_BOUND;

    hpid[1] = hpid[0];
    hpid[2] = hpid[0];
    hpid[3] = hpid[0];
    

    hpid_lowspeed[0].enable = 1;
    hpid_lowspeed[0].enable_lim_sum_error = 1;
    hpid_lowspeed[0].enable_lim_output_up = 1;
    hpid_lowspeed[0].enable_lim_output_dn = 1;
    
    hpid_lowspeed[0].kp = 3.6;
    hpid_lowspeed[0].ki = 0.0;
    hpid_lowspeed[0].kd = 0;

    hpid_lowspeed[0].lim_sum_error = 2000;
    hpid_lowspeed[0].lim_output_up = MOTOR_UP_BOUND;
    hpid_lowspeed[0].lim_output_dn = MOTOR_DN_BOUND;

    hpid_lowspeed[1] = hpid_lowspeed[0];
    hpid_lowspeed[2] = hpid_lowspeed[0];
    hpid_lowspeed[3] = hpid_lowspeed[0];
}


float feedforward_cw(float rpm)
{
    float ctrl_cur = feedforward_cw_k2 * rpm * rpm + feedforward_cw_k1 * rpm + feedforward_cw_k0;
    if(rpm < 2000)
    {
        return 0;
    }
    else
    {
        return ctrl_cur;
    }
}

float feedforward_ccw(float rpm)
{
    float ctrl_cur = feedforward_ccw_k2 * rpm * rpm + feedforward_ccw_k1 * rpm + feedforward_ccw_k0;
    if(rpm < 2000)
    {
        return 0;
    }
    else
    {
        return ctrl_cur;
    }
}

void Pulse_CAP_Callback(pwm_ch ch, uint32_t capval)
{
    pulse[ch].last_ms = get_sys_ms();
    pulse[ch].width = capval;
    return;
}

int16_t data[16] = {0};
uint8_t buff[256] = {0};
uint16_t len = 0;

void Cycle10msCallback(void)
{
    uint32_t curtime = get_sys_ms();

    if
    (
						1
        &&  (curtime - pulse[0].last_ms) < 20
        &&  (curtime - pulse[1].last_ms) < 20
        &&  (curtime - pulse[2].last_ms) < 20
        &&  (curtime - pulse[3].last_ms) < 20
    )
    {
        HAL_IWDG_Refresh(&hiwdg);
        
        int i;

        for(i = 0; i <= 3; i++)
        {
            if(pulse[i].width < MIN_PULSE_US)
            {
                rpm[i] = 0;
            }
            else if(pulse[i].width > MAX_PULSE_US)
            {
                rpm[i] = MAX_RPM;
            }
            else
            {
                rpm[i] = ((float)pulse[i].width - MIN_PULSE_US) / (float)(MAX_PULSE_US - MIN_PULSE_US) * (float)(MAX_RPM - MIN_RPM);
            }
        }
    }
    
    int16_t ctrl_cur[4] = {0};
    int i;
    for(i = 0; i <= 3; i++)
    {
        if(rpm[i] <= SHUTDOWN_THRESHOLD_RPM)
        {
            ctrl_cur[i] = 0;
        }
        else if(rpm[i] >= SHUTDOWN_THRESHOLD_RPM && rpm[i] <= LOW_SPEED_THRESHOLD_RPM)
        {
            ctrl_cur[i] = (int)pidProcess(&hpid_lowspeed[i], rpm[i], (float)motor[i].speed_rpm);
        }
        else
        {
            ctrl_cur[i] = feedforward_ccw(rpm[i]) + (int)pidProcess(&hpid[i], rpm[i], (float)motor[i].speed_rpm);
            check_bound(&ctrl_cur[i],  MOTOR_UP_BOUND, MOTOR_DN_BOUND);
        }
    }
    // printf("%d %d %d %d\r\n", pulse[0].width, pulse[1].width, pulse[2].width, pulse[3].width);
    CAN_cmd_motor(ctrl_cur[0], ctrl_cur[1], ctrl_cur[2], ctrl_cur[3]);
    CAN_Send_RPM((uint16_t)rpm[0], (uint16_t)rpm[1], (uint16_t)rpm[2], (uint16_t)rpm[3]);

#ifdef ANO_DEBUG_PRINT
    for(i = 0; i<= 3; i++)
    {
        data[i * 4 + 0] = rpm[i];
        data[i * 4 + 1] = motor[i].speed_rpm;
        data[i * 4 + 2] = ctrl_cur[i];
        data[i * 4 + 3] = motor[i].given_current;
    }
    ANOPrintS16(1, data, 16, buff, &len);
    HAL_UART_Transmit_DMA(&huart2, buff, len);
#endif
}


int main(void)
{
    rpm[0] = 0;
    rpm[1] = 0;
    rpm[2] = 0;
    rpm[3] = 0;
    pidInit();
    HAL_Init();

    SystemClock_Config_HSE();

    MX_GPIO_Init(); 
    MX_DMA_Init();
    MX_CAN_Init();

    //DEBUG UART
    MX_USART2_UART_Init();


    //PWM CAP
    MX_TIM2_Init();
    MX_TIM14_Init();
    MX_TIM16_Init();
    MX_TIM17_Init();
    
    // printf("M100Ctrl_PWM2CAN\r\n");

    MX_IWDG_Init();

    //SYS CLOCK
    MX_TIM1_Init();

    can_filter_init();    
    
    HAL_TIM_Base_Start_IT(&htim1);
    cap_start();

    while(1)
    {
        if(clock.cycle_10ms >= 10)
        {
            clock.cycle_10ms = 0;
            Cycle10msCallback();
        }
    }
}








