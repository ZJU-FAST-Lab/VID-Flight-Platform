#ifndef __CANMOTOR_H
#define __CANMOTOR_H
#ifdef __cplusplus
    extern "C" {
#endif

#include "main.h"


#define M1_REVERSE  (1)
#define M2_REVERSE  (0)
#define M3_REVERSE  (1)
#define M4_REVERSE  (0)


#define MOTOR_UP_BOUND  16384
#define MOTOR_DN_BOUND  -16384


#define get_motor_measure(ptr, data)                                    \
    {                                                                   \
        (ptr)->last_ecd = (ptr)->ecd;                                   \
        (ptr)->ecd = (uint16_t)((data)[0] << 8 | (data)[1]);            \
        (ptr)->speed_rpm = (uint16_t)((data)[2] << 8 | (data)[3]);      \
        (ptr)->given_current = (uint16_t)((data)[4] << 8 | (data)[5]);  \
        (ptr)->temperate = (data)[6];                                   \
    }

#define get_motor_measure_reverse(ptr, data)                                \
    {                                                                       \
        (ptr)->last_ecd = (ptr)->ecd;                                       \
        (ptr)->ecd = (uint16_t)((data)[0] << 8 | (data)[1]);                \
        (ptr)->speed_rpm = -((uint16_t)((data)[2] << 8 | (data)[3]));       \
        (ptr)->given_current = -((uint16_t)((data)[4] << 8 | (data)[5]));   \
        (ptr)->temperate = (data)[6];                                       \
    }

typedef enum
{
    CAN_CHASSIS_ALL_ID = 0x200,
    CAN_3508_M1_ID = 0x201,
    CAN_3508_M2_ID = 0x202,
    CAN_3508_M3_ID = 0x203,
    CAN_3508_M4_ID = 0x204,
} can_msg_id_e;

#define CAN_RPM_ID  0x100

typedef struct
{
    uint16_t ecd;
    int16_t speed_rpm;
    int16_t given_current;
    uint8_t temperate;
    int16_t last_ecd;
} motor_measure_t;

typedef struct
{
    int16_t current1;
    int16_t current2;
    int16_t current3;
    int16_t current4;
} ctrl_current_t;

typedef struct
{
    int16_t rpm1;
    int16_t rpm2;
    int16_t rpm3;
    int16_t rpm4;
} target_rpm_t;

void check_bound(int16_t *pval, int16_t upbound, int16_t dnbound);
void motor_bound(int16_t *pmotor1, int16_t *pmotor2, int16_t *pmotor3, int16_t *pmotor4, int16_t upbound, int16_t dnbound);
void can_filter_init(void);
void CAN_cmd_motor(int16_t motor1, int16_t motor2, int16_t motor3, int16_t motor4);


void CANMotorMsgCallback(can_msg_id_e id, motor_measure_t *pmotor);
void CANCtrlMsgCallback(ctrl_current_t *pctrl);


extern motor_measure_t motor[4];
extern ctrl_current_t ctrl;
extern target_rpm_t rpm;


#ifdef __cplusplus
}
#endif
#endif




