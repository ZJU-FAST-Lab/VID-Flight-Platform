#ifndef __GENPACK_H
#define __GENPACK_H
#ifdef __cplusplus
    extern "C" {
#endif

#include "main.h"

#define PACK_HD1                0xa5
#define PACK_HD2                0x12

#define PACK_CMD_MOTOR          0xf0
#define PACK_CMD_CTRL           0xf1
#define PACK_CMD_RPM            0xf2
#define PACK_CMD_PULSE_CAP      0xa0


void GenMotorPack(uint8_t *buff, uint32_t *len, uint8_t motorid, motor_measure_t *pmotor, time_t *ptime);
void GenCtrlPack(uint8_t *buff, uint32_t *len, ctrl_current_t *pctrl, time_t *ptime);
void GenRPMPack(uint8_t *buff, uint32_t *len, target_rpm_t *prpm, time_t *ptime);
void GenPPSPack(uint8_t *buff, uint32_t *len, time_t *ptime);
void GenCameraPack(uint8_t *buff, uint32_t *len, time_t *ptime);


#ifdef __cplusplus
}
#endif
#endif




