
#include "canfilter.h"


void CAN_FilterInitALLPASS(CAN_HandleTypeDef *hdl, uint32_t FilterBankID, uint32_t FIFOAssignment)
{
    CAN_FilterTypeDef FilterConfig = {0};

    FilterConfig.FilterBank             = FilterBankID ;
    FilterConfig.FilterMode             = CAN_FILTERMODE_IDMASK;
    FilterConfig.FilterScale            = CAN_FILTERSCALE_32BIT;

    FilterConfig.FilterIdHigh           = 0x0000;
    FilterConfig.FilterIdLow            = 0x0000;
    FilterConfig.FilterMaskIdHigh       = 0x0000;
    FilterConfig.FilterMaskIdLow        = 0x0000;
    FilterConfig.FilterFIFOAssignment   = FIFOAssignment;
    FilterConfig.FilterActivation       = ENABLE;

    HAL_CAN_ConfigFilter(hdl, &FilterConfig);
}

void CAN_FilterInit(CAN_HandleTypeDef *hdl, FilterUnit unit, uint32_t FilterBankID)
{
    CAN_FilterTypeDef FilterConfig = {0};

    FilterConfig.FilterBank             = FilterBankID;
    FilterConfig.FilterFIFOAssignment   = unit.FilterFIFO;
    FilterConfig.FilterActivation       = ENABLE;                   //过滤器使能

    switch (unit.mode)
    {
        case MODE_MASK32:
            FilterConfig.FilterMode     = CAN_FILTERMODE_IDMASK;
            FilterConfig.FilterScale    = CAN_FILTERSCALE_32BIT;
            break;
        case MODE_LIST32:
            FilterConfig.FilterMode     = CAN_FILTERMODE_IDLIST;
            FilterConfig.FilterScale    = CAN_FILTERSCALE_32BIT;
            break;
        case MODE_MASK16:
            FilterConfig.FilterMode     = CAN_FILTERMODE_IDMASK;
            FilterConfig.FilterScale    = CAN_FILTERSCALE_16BIT; 
            break;
        case MODE_LIST16:
            FilterConfig.FilterMode     = CAN_FILTERMODE_IDLIST;
            FilterConfig.FilterScale    = CAN_FILTERSCALE_16BIT;
        break;
    
    }

    FilterConfig.FilterIdLow        = unit.reg.hal.FilterIdLow;
    FilterConfig.FilterIdHigh       = unit.reg.hal.FilterIdHigh;
    FilterConfig.FilterMaskIdLow    = unit.reg.hal.FilterMaskIdLow;
    FilterConfig.FilterMaskIdHigh   = unit.reg.hal.FilterMaskIdHigh;

    HAL_CAN_ConfigFilter(hdl, &FilterConfig);
    
}
