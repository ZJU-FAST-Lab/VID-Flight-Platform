#include "canmotor.h"
#include "canfilter.h"

motor_measure_t motor[4];
ctrl_current_t ctrl;
target_rpm_t rpm;




__weak void CANMotorMsgCallback(can_msg_id_e id, motor_measure_t *pmotor)
{
    return;
}

__weak void CANCtrlMsgCallback(ctrl_current_t *pctrl)
{
    return;
}

__weak void CANRPMMsgCallback(target_rpm_t *prpm)
{
    return;
}


void HAL_CAN_RxFifo0MsgPendingCallback(CAN_HandleTypeDef *hcan)
{
    CAN_RxHeaderTypeDef rx_header;
    uint8_t rx_data[8];

    HAL_CAN_GetRxMessage(hcan, CAN_RX_FIFO0, &rx_header, rx_data);

    switch (rx_header.StdId)
    {
        case CAN_3508_M1_ID:
#if M1_REVERSE        
            get_motor_measure_reverse(&motor[0], rx_data);
#else            
            get_motor_measure(&motor[0], rx_data);
#endif
            CANMotorMsgCallback(CAN_3508_M1_ID, &motor[0]);
            break;

        case CAN_3508_M2_ID:
#if M2_REVERSE        
            get_motor_measure_reverse(&motor[1], rx_data);
#else            
            get_motor_measure(&motor[1], rx_data);
#endif
            CANMotorMsgCallback(CAN_3508_M2_ID, &motor[1]);
            break;

        case CAN_3508_M3_ID:
#if M3_REVERSE        
            get_motor_measure_reverse(&motor[2], rx_data);
#else            
            get_motor_measure(&motor[2], rx_data);
#endif
            CANMotorMsgCallback(CAN_3508_M3_ID, &motor[2]);
            break;

        case CAN_3508_M4_ID:
#if M4_REVERSE        
            get_motor_measure_reverse(&motor[3], rx_data);
#else            
            get_motor_measure(&motor[3], rx_data);
#endif       
            CANMotorMsgCallback(CAN_3508_M4_ID, &motor[3]);
            break;


        case CAN_CHASSIS_ALL_ID:
#if M1_REVERSE
            ctrl.current1 = -((rx_data[0] << 8) | rx_data[1]);
#else            
            ctrl.current1 = (rx_data[0] << 8) | rx_data[1];
#endif

#if M2_REVERSE
            ctrl.current2 = -((rx_data[2] << 8) | rx_data[3]);
#else            
            ctrl.current2 = (rx_data[2] << 8) | rx_data[3];
#endif

#if M3_REVERSE
            ctrl.current3 = -((rx_data[4] << 8) | rx_data[5]);
#else            
            ctrl.current3 = (rx_data[4] << 8) | rx_data[5];
#endif

#if M4_REVERSE
            ctrl.current4 = -((rx_data[6] << 8) | rx_data[7]);
#else            
            ctrl.current4 = (rx_data[6] << 8) | rx_data[7];
#endif
            CANCtrlMsgCallback(&ctrl);
            break;

        case CAN_RPM_ID:
            rpm.rpm1 = (rx_data[1] << 8) | rx_data[0];
            rpm.rpm2 = (rx_data[3] << 8) | rx_data[2];
            rpm.rpm3 = (rx_data[5] << 8) | rx_data[4];
            rpm.rpm4 = (rx_data[7] << 8) | rx_data[6];
            CANRPMMsgCallback(&rpm);
            break;
        
        default:
        {
            break;
        }
    }
}

void can_filter_init(void)
{
    FilterUnit unit;

    unit.FilterFIFO = CAN_RX_FIFO0;
    unit.mode = MODE_LIST16;
    unit.reg.list16.IDE1 = 0;
    unit.reg.list16.RTR1 = 0;
    unit.reg.list16.IDE2 = 0;
    unit.reg.list16.RTR2 = 0;
    unit.reg.list16.IDE3 = 0;
    unit.reg.list16.RTR3 = 0;
    unit.reg.list16.IDE4 = 0;
    unit.reg.list16.RTR4 = 0;
    unit.reg.list16.StdID1 = CAN_3508_M1_ID;
    unit.reg.list16.StdID2 = CAN_3508_M2_ID;
    unit.reg.list16.StdID3 = CAN_3508_M3_ID;
    unit.reg.list16.StdID4 = CAN_3508_M4_ID;
    CAN_FilterInit(&hcan, unit, 0);

    unit.FilterFIFO = CAN_RX_FIFO0;
    unit.mode = MODE_LIST16;
    unit.reg.list16.IDE1 = 0;
    unit.reg.list16.RTR1 = 0;
    unit.reg.list16.IDE2 = 0;
    unit.reg.list16.RTR2 = 0;
    unit.reg.list16.IDE3 = 0;
    unit.reg.list16.RTR3 = 0;
    unit.reg.list16.IDE4 = 0;
    unit.reg.list16.RTR4 = 0;
    unit.reg.list16.StdID1 = CAN_CHASSIS_ALL_ID;
    unit.reg.list16.StdID2 = CAN_RPM_ID;
    unit.reg.list16.StdID3 = 0x0;
    unit.reg.list16.StdID4 = 0x0;
    CAN_FilterInit(&hcan, unit, 1);

    HAL_CAN_Start(&hcan);
    HAL_CAN_ActivateNotification(&hcan, CAN_IT_RX_FIFO0_MSG_PENDING);
}


static CAN_TxHeaderTypeDef  tx_message;
static uint8_t              can_send_data[8];

void check_bound(int16_t *pval, int16_t upbound, int16_t dnbound)
{
    if(*pval > upbound)
    {
        *pval = upbound;
    }
    else if(*pval < dnbound)
    {
        *pval = dnbound;
    }
}

void motor_bound(int16_t *pmotor1, int16_t *pmotor2, int16_t *pmotor3, int16_t *pmotor4, int16_t upbound, int16_t dnbound)
{
    check_bound(pmotor1, upbound, dnbound);
    check_bound(pmotor2, upbound, dnbound);
    check_bound(pmotor3, upbound, dnbound);
    check_bound(pmotor4, upbound, dnbound);
}

void CAN_cmd_motor(int16_t motor1, int16_t motor2, int16_t motor3, int16_t motor4)
{
    uint32_t send_mail_box;
    motor_bound(&motor1, &motor2, &motor3, &motor4, MOTOR_UP_BOUND, MOTOR_DN_BOUND);

#if M1_REVERSE
    motor1 = -motor1;
#endif

#if M2_REVERSE
    motor2 = -motor2;
#endif

#if M3_REVERSE
    motor3 = -motor3;
#endif

#if M4_REVERSE
    motor4 = -motor4;
#endif

    tx_message.StdId = CAN_CHASSIS_ALL_ID;
    tx_message.IDE = CAN_ID_STD;
    tx_message.RTR = CAN_RTR_DATA;
    tx_message.DLC = 0x08;
    can_send_data[0] = motor1 >> 8;
    can_send_data[1] = motor1;
    can_send_data[2] = motor2 >> 8;
    can_send_data[3] = motor2;
    can_send_data[4] = motor3 >> 8;
    can_send_data[5] = motor3;
    can_send_data[6] = motor4 >> 8;
    can_send_data[7] = motor4;

    HAL_CAN_AddTxMessage(&hcan, &tx_message, can_send_data, &send_mail_box);
}


