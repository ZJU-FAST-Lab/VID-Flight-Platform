
#ifndef __sys_H
#define __sys_H
#ifdef __cplusplus
 extern "C" {
#endif

#include "main.h"


void SystemClock_Config_HSI(void);
void SystemClock_Config_HSE(void);


#ifdef __cplusplus
}
#endif
#endif
