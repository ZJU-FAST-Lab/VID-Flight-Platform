/**
  ******************************************************************************
  * File Name          : TIM.h
  * Description        : This file provides code for the configuration
  *                      of the TIM instances.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __tim_H
#define __tim_H
#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "main.h"



#define sys_sec_reg         (TIM2->CNT)

#define CCR_REG_PPS         (TIM2->CCR1)
#define CCR_REG_CAMERA      (TIM2->CCR2)

typedef struct
{
    uint32_t sys_sec;
} clock_t;

typedef struct
{
    uint32_t sec;
    uint32_t usec;
} time_t;

extern TIM_HandleTypeDef htim2;
extern TIM_HandleTypeDef htim14;


void MX_TIM2_Init(void);
void MX_TIM14_Init(void);

float gettime_sec(void);
uint64_t gettime_us(void);
time_t gettime(void);

void HAL_TIM_MspPostInit(TIM_HandleTypeDef* timHandle);




extern clock_t clock;




#ifdef __cplusplus
}
#endif
#endif /*__ tim_H */

/**
  * @}
  */

/**
  * @}
  */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
