
#include "main.h"

#include "canmotor.h"
#include "pid.h"
#include "ANO.h"
#include "genpack.h"

uint8_t motor_flag[4] = {0};
uint8_t ctrl_flag = 0;
uint8_t rpm_flag = 0;
uint8_t pps_flag = 0;
uint8_t camera_flag = 0;

time_t motor_time[4] = {0};
time_t ctrl_time = {0};
time_t rpm_time = {0};
time_t pps_time = {0};
time_t camera_time = {0};

void CANMotorMsgCallback(can_msg_id_e id, motor_measure_t *pmotor)
{
    switch (id)
    {
    case CAN_3508_M1_ID:
        motor_time[0] = gettime();
        motor_flag[0] = 1;
        break;
    case CAN_3508_M2_ID:
        motor_time[1] = gettime();
        motor_flag[1] = 1;
        break;
    case CAN_3508_M3_ID:
        motor_time[2] = gettime();
        motor_flag[2] = 1;
        break;
    case CAN_3508_M4_ID:
        motor_time[3] = gettime();
        motor_flag[3] = 1;
        break;
    default:
        break;
    }
    return;
}

void CANCtrlMsgCallback(ctrl_current_t *pctrl)
{
    ctrl_time = gettime();
    ctrl_flag = 1;
    return;
}

void CANRPMMsgCallback(ctrl_current_t *pctrl)
{
    rpm_time = gettime();
    rpm_flag = 1;
    return;
}

void PPSCAPCallback(time_t ts)
{
    pps_time = ts;
    pps_flag = 1;
    return;
}

void CameraPulseCAPCallback(time_t ts)
{
    camera_time = ts;
    camera_flag = 1;
    return;
}

int main(void)
 {
    HAL_Init();

    SystemClock_Config_HSE();

    //LED GPIO
    MX_GPIO_Init();

    //DMA only for UART2
    MX_DMA_Init();

    MX_CAN_Init();

    //DEBUG UART
    MX_USART2_UART_Init();




    // printf("M100Ctrl_RPM\r\n");

    // MX_IWDG_Init();

    //SYS CLOCK
    MX_TIM2_Init();    
    HAL_TIM_Base_Start_IT(&htim2);
    HAL_TIM_IC_Start_IT(&htim2, TIM_CHANNEL_1);
    HAL_TIM_IC_Start_IT(&htim2, TIM_CHANNEL_2);

#ifndef SYNC_REALSENSE_MASTER
    // Realsens Sync
    MX_TIM14_Init();    
    HAL_TIM_PWM_Start(&htim14, TIM_CHANNEL_1);
#endif
    can_filter_init();



    uint8_t buff[256] = {0};
    uint32_t len = 0;

    while(1)
    {
        if(camera_flag != 0)
        {
            camera_flag = 0;
            GenCameraPack(buff, &len, &camera_time);
            HAL_UART_Transmit(&huart2, buff, len, 0xffff);
        }

        if(pps_flag != 0)
        {
            pps_flag = 0;
            GenPPSPack(buff, &len, &pps_time);
            HAL_UART_Transmit(&huart2, buff, len, 0xffff);
        }

        int i;
        for ( i = 0; i <= 3; i++)
        {
            if(motor_flag[i] != 0)
            {
                motor_flag[i] = 0;
                GenMotorPack(buff, &len, i + 1, &motor[i], &motor_time[i]);
                HAL_UART_Transmit(&huart2, buff, len, 0xffff);
            }
        }

        if(ctrl_flag != 0)
        {
            ctrl_flag = 0;
            GenCtrlPack(buff, &len, &ctrl, &ctrl_time);
            HAL_UART_Transmit(&huart2, buff, len, 0xffff);
        }

        if(rpm_flag != 0)
        {
            rpm_flag = 0;
            GenRPMPack(buff, &len, &rpm, &rpm_time);
            HAL_UART_Transmit(&huart2, buff, len, 0xffff);
        }
    }
}








