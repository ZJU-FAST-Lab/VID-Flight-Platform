rosbag record \
/camera/depth/image_rect_raw \
/camera/infra1/image_rect_raw \
/camera/infra2/image_rect_raw \
/m100withm3508/cap_camerapulse \
/m100withm3508/target_rpm \
/m100withm3508/ctrl_current \
/m100withm3508/m3508_m1 \
/m100withm3508/m3508_m2 \
/m100withm3508/m3508_m3 \
/m100withm3508/m3508_m4 \
/m100withm3508/cap_n3pps \
/djiros/pulse \
/djiros/imu_hwts \
/djiros/imu \
/vicon/m100/m100 \
/robotiq_ft_wrench \
/robotiq_ft_sensor \
--tcpnodelay
