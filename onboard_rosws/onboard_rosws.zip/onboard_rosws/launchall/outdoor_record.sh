rosbag record \
/camera/depth/image_rect_raw \
/camera/infra1/image_rect_raw \
/camera/infra2/image_rect_raw \
/m100withm3508/cap_camerapulse \
/m100withm3508/target_rpm \
/m100withm3508/ctrl_current \
/m100withm3508/m3508_m1 \
/m100withm3508/m3508_m2 \
/m100withm3508/m3508_m3 \
/m100withm3508/m3508_m4 \
/m100withm3508/cap_n3pps \
/djiros/pulse \
/djiros/imu_hwts \
/djiros/imu \
/djiros/gps \
/rtk_zhd_parser/GPS \
/rtk_zhd_parser/Satellites \
/rtk_zhd_parser/Velocity \
/rtk_zhd_parser/Yaw \
--tcpnodelay
