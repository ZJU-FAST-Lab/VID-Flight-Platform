#!/bin/bash
source devel/setup.bash

# roslaunch rstools set_rssyncmode.launch & sleep 10
sudo chmod 777 /dev/ttyUSB0  & sleep 1
sudo chmod 777 /dev/ttyUSB1  & sleep 1
sudo chmod 777 /dev/ttyUSB2  & sleep 1
roslaunch uavmotor m100withm3508.launch & sleep 5
roslaunch djiros djiros.launch & sleep 10
roslaunch realsense2_camera rs_camera.launch  & sleep 10
roslaunch vicon_bridge vicon.launch & sleep 1
wait


